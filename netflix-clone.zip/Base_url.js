
export const base_url = 'https://api.themoviedb.org/3/movie'
