import React from 'react'
import YouTube from 'react-youtube' 

export default function Video() {
  return (
    <div><YouTube /></div>
  )
}
